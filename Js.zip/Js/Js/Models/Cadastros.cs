﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Js.Models
{
    class Cadastros
    {
        public int id_cadastro;

        public String nome;

        public String carro;

        public String placa;

        public DateTime data;
    }
}
